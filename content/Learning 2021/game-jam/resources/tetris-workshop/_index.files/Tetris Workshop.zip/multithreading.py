from multiprocessing import Process
import time

def ticker(interval):
    counter = 1
    while True:
        print("Tick", counter)
        counter += 1
        time.sleep(interval)

if __name__ == "__main__": # Standard python convention for child processes
    p = Process(target = ticker, args = (1,)) # Create a new process
    p.start() # Start the process
    while True:
        cmd = input().strip()
        if cmd == 'q':
            break
        print("Tock!")

    p.terminate() # Terminate the process
    print("Process ended")
