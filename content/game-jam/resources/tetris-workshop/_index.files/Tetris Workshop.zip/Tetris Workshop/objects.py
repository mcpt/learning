class Baby:
    # The constructor for the Baby class. This creates a new Baby object.
    def __init__(self, name, length, birthdate):
        # Assign the parameters to the instance fields. The "self" keyword
        # shows that the field is specific to this instance of the class (not all babies have the same name, length, or birthdate)
        self.name = name
        self.length = length
        self.birthdate = birthdate
    
    # Instance method that displays info about the baby
    # Any instance methods must contain the parameter "self"
    def showOff(self):
        print("My name is", self.name + ". I am", self.length, "inches long, and I was born on", self.birthdate.to_string())

class Date:
    def __init__(self, year, month, day):
        self.year = year
        self.month = month
        self.day = day

    # Converts the date to a readable string
    def to_string(self):
        return str(self.year) + "-" + str(self.month) + "-" + str(self.day)

myBaby = Baby("Sally", 20.1, Date(2021, 12, 25)) # Create a new baby object using the constructor
myBaby.showOff()